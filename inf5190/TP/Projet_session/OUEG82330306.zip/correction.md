﻿﻿Oueyeya Gaëtan

OUEG82330306
# <a name="_ny6fo1xwv7s8"></a>Remise Projet de Session

## <a name="_c5vh6cfddtjg"></a>Points développés:

A1. Le script se situe dans le fichier db/get\_data.py

A2. Il faut lancer l’application et la recherche se trouve au niveau de la barre de recherche. code sur index.py, fonction display\_search (ligne 86)

A3. Dans mon code la fonction se trouve sur index.py ligne 63 (Crontrigger).

A4. Le lien de l’explication de l’API se trouve dans le navbar. code sur index.py ligne 117.

A5. La fonctionnalité se trouve sur la page d’accueil. Le script JS se trouve dans le fichier static/js/script.js.

A6. La fonctionnalité se trouve sur la page d’accueil. Le code pour cette fonctionnalité se trouve sur index.py ligne 143.

B1. Le code se trouve sur index.py, ligne 160 et cette fonction est appelée par le CronTrigger ligne 63.

C1. Le code se trouve sur index.py, ligne 201. Visualisation des données en json.

C2. Le code se trouve sur index.py, ligne 209. Visualisation des données en xml.

C3. Le code se trouve sur index.py, ligne 232. Un fichier csv est retourné et téléchargé automatiquement.

D1. Les schémas se trouvent dans le fichier schemas.py. Le code se trouve sur index.py, ligne 245. Le service se trouve dans le navbar et est intitulé “Demande d’inspection”. Le script JS se trouve dans static/js/script.js.

D2. Le code se trouve sur index.py, ligne 266. L’explication du service REST se trouve sur la route /doc.

E1.Les schémas se trouvent dans le fichier schemas.py. Le code se trouve sur index.py, ligne 279. Le service est documenté sur /doc.
E2. Le code se trouve sur index.py, ligne 298-412. Il existe deux fichiers JS dans static/js/ nommés script\_account.js et script\_form\_sub.js. Chaque utilisateur à par défaut une image qui est stockée dans la bd mais il peut la changer.
